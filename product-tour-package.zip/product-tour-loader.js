(function () {
  // プロダクトツアーローダー（追加のみで利用可）
  // 配置: frontend/public/ に置く
  // 自動読み込みする場合は HTML に <script src="/product-tour-loader.js"></script> を追加
  // ツアー定義: /product-tour.json（各ステップに ID, url を指定）

  // ドキュメントに挿入する style 要素の ID
  const STYLE_ID = 'product-tour-loader-style';
  // オーバーレイ全体を包む要素の ID
  const OVERLAY_ID = 'product-tour-overlay';
  // ポップオーバー（吹き出し）のルート要素の ID
  const POPOVER_ID = 'product-tour-popover';

  // ページに埋め込むスタイルを生成します（オーバーレイ、ポップオーバー等）。
  // 既に挿入されている場合は何もしません。
  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const css = `
#${OVERLAY_ID} { position:fixed;inset:0;z-index:2147483000;pointer-events:none; }
.product-tour-pane { position:fixed;background:rgba(0,0,0,0.55);pointer-events:auto; }
#${POPOVER_ID} { position:fixed; z-index:2147483100; pointer-events:auto; max-width:360px; }
#${POPOVER_ID} .card{ background:white;border-radius:8px;padding:12px 14px;box-shadow:0 8px 24px rgba(0,0,0,0.2); }
#${POPOVER_ID} .title{ font-weight:700;margin-bottom:6px }
#${POPOVER_ID} .desc{ white-space:pre-wrap;margin-bottom:8px }
#${POPOVER_ID} .controls{ display:flex;justify-content:flex-end;gap:8px }
.product-tour-tail{ position:absolute;width:0;height:0 }
`;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.innerHTML = css;
    document.head.appendChild(style);
  }

  // オーバーレイ要素を取得または作成
  // ポップオーバー要素を取得または作成
  function createOverlayElements() {
    let overlay = document.getElementById(OVERLAY_ID);
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = OVERLAY_ID;
      // 上・左・右・下の4パネル
      ['top', 'left', 'right', 'bottom'].forEach((p) => {
        const d = document.createElement('div');
        d.className = 'product-tour-pane product-tour-pane-' + p;
        overlay.appendChild(d);
      });
      document.body.appendChild(overlay);
    }

    let pop = document.getElementById(POPOVER_ID);
    if (!pop) {
      pop = document.createElement('div');
      pop.id = POPOVER_ID;
      pop.innerHTML = `
        <div class="card">
          <div class="title"></div>
          <div class="desc"></div>
          <div class="controls"></div>
        </div>
        <div class="product-tour-tail"></div>
      `;
      document.body.appendChild(pop);
    }

    return { overlay, pop };
  }

  // 値を範囲 [a, b] にクランプするユーティリティ
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  // ポーリング間隔と最大試行回数を定数化（環境に応じて調整可）
  const POLL_INTERVAL_MS = 500; // 要素探索の間隔
  const MAX_TRIES = 120; // デフォルト: 120 試行 -> 約 60 秒

  function positionOverlay(panes, rect) {
    const vw = window.innerWidth, vh = window.innerHeight;
    const top = panes.querySelector('.product-tour-pane-top');
    const left = panes.querySelector('.product-tour-pane-left');
    const right = panes.querySelector('.product-tour-pane-right');
    const bottom = panes.querySelector('.product-tour-pane-bottom');

    top.style.left = '0px'; top.style.top = '0px'; top.style.width = vw + 'px'; top.style.height = rect.top + 'px';

    bottom.style.left = '0px'; bottom.style.top = rect.top + rect.height + 'px'; bottom.style.width = vw + 'px'; bottom.style.height = (vh - rect.top - rect.height) + 'px';

    left.style.left = '0px'; left.style.top = rect.top + 'px'; left.style.width = rect.left + 'px'; left.style.height = rect.height + 'px';

    right.style.left = rect.left + rect.width + 'px'; right.style.top = rect.top + 'px'; right.style.width = (vw - rect.left - rect.width) + 'px'; right.style.height = rect.height + 'px';
  }

  // ポップオーバーの位置を計算して配置します。
  // placement は 'below' または 'above' を想定しています。
  function positionPopover(pop, rect, placement = 'below') {
    const tail = pop.querySelector('.product-tour-tail');
    const card = pop.querySelector('.card');
    const vw = window.innerWidth, vh = window.innerHeight;
    const preferredW = Math.min(360, vw - 24);
    card.style.maxWidth = preferredW + 'px';

    // ポップオーバーがターゲット中央に来るよう左位置を計算（画面端でクランプ）
    let left = rect.left + rect.width / 2 - preferredW / 2;
    left = clamp(left, 8, vw - preferredW - 8);

    let top;
    if (placement === 'below') top = rect.top + rect.height + 12;
    else top = rect.top - 12 - card.offsetHeight;

    if (top < 8) top = 8;
    if (top + card.offsetHeight > vh - 8) top = vh - 8 - card.offsetHeight;

    pop.style.left = Math.round(left) + 'px';
    pop.style.top = Math.round(top) + 'px';

    // 三角（ツノ）の位置調整
    const tailLeft = clamp(rect.left + rect.width/2 - left - 8, 12, preferredW - 28);
    tail.style.left = tailLeft + 'px';
    if (placement === 'below') {
      tail.style.top = '-12px';
      tail.style.borderLeft = '8px solid transparent';
      tail.style.borderRight = '8px solid transparent';
      tail.style.borderTop = '12px solid white';
      tail.style.borderBottom = 'none';
    } else {
      tail.style.top = (card.offsetHeight) + 'px';
      tail.style.borderLeft = '8px solid transparent';
      tail.style.borderRight = '8px solid transparent';
      tail.style.borderBottom = '12px solid white';
      tail.style.borderTop = 'none';
    }
  }

  // ツアーの実行を行うランナーを生成します。
  // tours: ロードされたツアー配列
  function createRunner(tours) {
    let activeTour = null; let index = 0; let stop = false; let clickRemover = null;
    const STATE_KEY = 'product-tour-state';
    const { overlay, pop } = createOverlayElements();
    const panes = overlay;

    // イベントリスナと付帯処理を解除するユーティリティ
    function clearListeners() {
      if (clickRemover) { clickRemover(); clickRemover = null; }
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('resize', onResize);
      try { window.removeEventListener('product-tour-ready', onProductTourReady); } catch (e) {}
    }

    function onResize() { if (!activeTour) return; showStep(activeTour, index); }
    function onKey(e) { if (e.key === 'Escape') endTour(); }

    // ツアーを終了する。UI を消し、リスナを解除して終了イベントを発火する。
    function endTour() {
      stop = true; activeTour = null; index = 0;
      overlay.style.display = 'none'; pop.style.display = 'none';
      clearListeners();
      window.dispatchEvent(new CustomEvent('product-tour-ended'));
    }

    // 指定ツアーのステップを表示
    // url があれば遷移指示（state を保存）
    // 要素が無ければ再試行して中断
    function showStep(t, i) {
      const step = t.steps[i];
      if (!step) { endTour(); return; }
      // url があれば現在のパスと比較して遷移を指示
      if (step.url) {
        try {
          const target = new URL(step.url, location.origin).pathname;
          const current = location.pathname;
          if (current !== target) {
            try { sessionStorage.setItem(STATE_KEY, JSON.stringify({ name: t.name, index: i })); } catch(e){}
            // SPA が受け取らなければフォールバックで location.href へ
            try {
              window.dispatchEvent(new CustomEvent('product-tour-navigate', { detail: { url: step.url } }));
            } catch (e) {
              location.href = step.url;
            }
            return;
          }
        } catch(e) {}
      }

      const selector = step.requiredSelector || step.selector || (step.ID ? '#'+step.ID : null) || null;
      let el = null;
      try { if (selector) el = document.querySelector(selector); } catch {}
      if (!el) {
        // ID が指定されていればそれで取得を試みる
        if (step.ID) el = document.getElementById(step.ID);
      }

      if (!el) {
        // 非同期描画などで要素がまだ無い場合は再試行する（最大試行回数あり）。
        step.__tries = (step.__tries || 0) + 1;
        if (step.__tries > MAX_TRIES) {
          // 所定回数以上見つからなければツアーを中断
          endTour();
          return;
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
        setTimeout(() => showStep(t, i), POLL_INTERVAL_MS);
        return;
      }

      const r = el.getBoundingClientRect();
      const rect = { top: r.top + window.scrollY, left: r.left + window.scrollX, width: r.width, height: r.height };
      overlay.style.display = '';
      pop.style.display = '';
      positionOverlay(panes, rect);
      positionPopover(pop, rect, 'below');

      // ポップオーバーにタイトル・本文をセット
      pop.querySelector('.title').textContent = step.title || step.ID || t.name || '';
      pop.querySelector('.desc').textContent = step.content || step.description || step.テキスト || '';

      const controls = pop.querySelector('.controls');
      controls.innerHTML = '';

      // 以前のクリックリスナがあれば削除
      if (clickRemover) { clickRemover(); clickRemover = null; }

      const isButton = (step.type === 'button' || step.タイプ === 'button' || step.requiredSelector);

      if (isButton) {
        // ボタンタイプ: ポップオーバーの "次へ" を表示せず、対象要素のクリックを待ちます
        // （例: フォームの送信ボタンをユーザーが押すことで次のステップへ進む）
        const info = document.createElement('div');
        info.textContent = 'このステップは対象をクリックしてください';
        info.style.marginRight = '8px';
        controls.appendChild(info);

        // 対象クリックを検出するためグローバルにクリックリスナを登録
        const handler = function (ev) {
          const path = ev.composedPath ? ev.composedPath() : (ev.path || []);
          if (!path || path.length === 0) {
            let t = ev.target; while (t) { path.push(t); t = t.parentElement; }
          }
          let matched = false;
          if (selector) {
            for (const p of path) {
              try { if (p && p.matches && p.matches(selector)) { matched = true; break; } } catch(e) {}
            }
          } else {
            // フォールバック: クリックが対象要素内か確認
            for (const p of path) {
              if (p === el) { matched = true; break; }
            }
          }
          if (matched) {
            // マッチする要素がクリックされたら次のステップへ
            nextStep();
          }
        };
        document.addEventListener('click', handler, true);
        clickRemover = () => document.removeEventListener('click', handler, true);
      } else {
        // 通常タイプ: ポップオーバー上に "次へ" / "完了" ボタンを表示して進行を制御
        if (i < t.steps.length - 1) {
          const b = document.createElement('button'); b.textContent = '次へ';
          b.onclick = nextStep; controls.appendChild(b);
        } else {
          const b = document.createElement('button'); b.textContent = '完了';
          b.onclick = endTour; controls.appendChild(b);
        }
      }

      // ページ遷移後に復帰できるよう現在の進捗を保存
      try { sessionStorage.setItem(STATE_KEY, JSON.stringify({ name: t.name, index: i })); } catch(e){}

      document.addEventListener('keydown', onKey);
      window.addEventListener('resize', onResize);
      // scroll element into view
      try { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e){}
    }

    function nextStep() {
      index++;
      // インデックスを進めて次のステップを表示
n      if (!activeTour) return;
      if (index >= activeTour.steps.length) { endTour(); return; }
      showStep(activeTour, index);
    }

    // 外部から「ページの準備ができた」ことを通知されると再試行するハンドラ
    function onProductTourReady() {
      if (!activeTour) return;
      try { showStep(activeTour, index); } catch (e) {}
    }

    function startByName(name, startAt = 0) {
      const t = (tours || []).find(x => x.name === name || x.tour === name);
      if (!t) return false;
      // 名前からツアーを探して開始（startAt を指定すると途中から開始可能）
      const errs = validateTour(t);
      if (errs && errs.length) {
        try { window.dispatchEvent(new CustomEvent('product-tour-error', { detail: { name: t.name, errors: errs } })); } catch(e){}
        try { console.warn('product-tour validation failed', errs); } catch(e){}
        try { alert('Product Tour エラー: ' + errs.join('\n')); } catch(e){}
        return false;
      }
      startTour(t, startAt); return true;
    }

    function startTour(t, startAt = 0) {
      // ツアーを開始する前に簡易バリデーションを行う
      const errs = validateTour(t);
      if (errs && errs.length) {
        try { window.dispatchEvent(new CustomEvent('product-tour-error', { detail: { name: t.name, errors: errs } })); } catch(e){}
        try { console.warn('product-tour validation failed', errs); } catch(e){}
        try { alert('Product Tour エラー: ' + errs.join('\n')); } catch(e){}
        return;
      }
      // ツアーを開始する。UI を表示して最初のステップを表示する。
      activeTour = t; index = startAt; stop = false; overlay.style.display = ''; pop.style.display = '';
      showStep(activeTour, index);
      // 開始イベントを発火（外部でフック可能）
      window.dispatchEvent(new CustomEvent('product-tour-started', { detail: { name: t.name } }));
    }

    // ツアー開始前の簡易検証
    function validateTour(t) {
      const errs = [];
      if (!t || !Array.isArray(t.steps) || t.steps.length === 0) {
        errs.push('ツアー定義が不正またはステップが空です');
        return errs;
      }
      // storage 利用可否を確認
      try {
        const key = '__product_tour_test__';
        sessionStorage.setItem(key, '1');
        sessionStorage.removeItem(key);
      } catch (e) {
        errs.push('sessionStorage が使用できません');
      }

      // 現在のパス
      const currentPath = location.pathname;
      (t.steps || []).forEach((step, idx) => {
        // url が指定されていて現在と異なる場合はページ遷移が必要なので現時点で存在確認しない
        if (step && step.url) {
          try {
            const target = new URL(step.url, location.origin).pathname;
            if (target !== currentPath) return; // 別ページなら先送り
          } catch (e) {
            // URL 解釈不能ならエラー
            errs.push(`ステップ ${idx+1}: 不正な url`);
            return;
          }
        }
        // 現在ページ上で存在が必要なセレクタをチェック
        const selector = step.requiredSelector || step.selector || (step.ID ? '#'+step.ID : null) || null;
        if (selector) {
          try {
            if (!document.querySelector(selector)) {
              errs.push(`ステップ ${idx+1}: 要素が見つかりません (${selector})`);
            }
          } catch (e) {
            errs.push(`ステップ ${idx+1}: selector が不正です (${selector})`);
          }
        }
      });
      return errs;
    }

    function destroy() { clearListeners(); if (overlay) overlay.remove(); if (pop) pop.remove(); }

    // 商品ツアー用の ready イベントを監視（遷移先で準備完了を通知できる）
    try { window.addEventListener('product-tour-ready', onProductTourReady); } catch(e){}

    return { startByName, startTour, endTour, destroy };
  }

  // bootstrap: fetch JSON and wire global API
  injectStyles();
  let RUNNER = null;

  // /product-tour.json を読み込み、内部で扱いやすい形に正規化して返す
  async function loadTours() {
    try {
      const res = await fetch('/product-tour.json', { cache: 'no-store' });
      if (!res.ok) return null;
      const data = await res.json();
      // normalize shape to { name, steps: [{ ID, title, content, selector, type, requiredSelector }] }
      const tours = (Array.isArray(data) ? data : (data.tours || [])).map(t => ({
        name: t.name || t.title || 'ツアー',
        steps: (t.items || t.steps || []).map((it) => ({
          ID: it.ID,
          title: it.ID || it.title,
          content: it.テキスト || it.content || it.description,
          selector: it.selector || (it.ID ? ('#'+it.ID) : null),
          type: it.タイプ || it.type || 'normal',
          requiredSelector: it.requiredSelector || null,
        }))
      }));
      return tours;
    } catch (e) { return null; }
  }

  async function init() {
    const tours = await loadTours();
    if (!tours) return;
    RUNNER = createRunner(tours);

    // resume state after navigation (supports full-page navigation and simple SPA back/forward)
    (function setupResume() {
      const STATE_KEY = 'product-tour-state';
      function tryResume() {
        try {
          const raw = sessionStorage.getItem(STATE_KEY);
          if (!raw) return;
          const st = JSON.parse(raw);
          if (!st || !st.name) return;
          if (!RUNNER) return;
          RUNNER.startByName(st.name, st.index || 0);
        } catch (e) {}
      }
      // 即時復帰を試行（ページ再読み込み時）
      tryResume();
      // SPA の履歴/ハッシュ変化を監視して復帰を試行
      window.addEventListener('popstate', tryResume);
      window.addEventListener('hashchange', tryResume);
      // SPA 側から明示的に復帰をトリガーできるようイベントを監視
      window.addEventListener('product-tour-resume', tryResume);
      // ページ準備完了イベントで復帰を試行できるようにする
      window.addEventListener('product-tour-ready', tryResume);
    })();

    // 外部 API を公開する: コンソールや他のスクリプトからツアー開始が可能
    window.startProductTour = function(name) {
      if (!RUNNER) return false;
      if (!name) return false;
      return RUNNER.startByName(name);
    };

    // JSON を直接渡して一時的なツアーを開始するためのイベント
    window.addEventListener('startTourFromJson', function(e) {
      const detail = e && e.detail ? e.detail : {};
      if (detail.items && Array.isArray(detail.items)) {
        // 一時的なツアーを構築して実行
        const t = { name: detail.name || 'Adhoc Tour', steps: detail.items.map(it => ({
          ID: it.ID, title: it.ID, content: it.テキスト || it.content, selector: it.requiredSelector || (it.ID ? '#'+it.ID : null), type: it.タイプ || it.type || 'normal', requiredSelector: it.requiredSelector || null
        })) };
        RUNNER.startTour(t);
        return;
      }
      if (detail.name) {
        RUNNER.startByName(detail.name);
      } else {
        // デフォルトで最初のツアーを開始
        RUNNER.startByName(tours[0] && (tours[0].name || tours[0].tour));
      }
    });

    // URL クエリ ?tour=NAME で自動開始
    const params = new URLSearchParams(location.search);
    const auto = params.get('tour') || null;
    if (auto) { setTimeout(()=> window.startProductTour(auto), 500); }
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') init();
  else window.addEventListener('DOMContentLoaded', init);
})();
